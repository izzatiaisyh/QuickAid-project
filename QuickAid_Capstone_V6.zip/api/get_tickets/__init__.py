import azure.functions as func
import json
import os
from azure.cosmos import CosmosClient
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

vault_url = "https://QuickAidVault.vault.azure.net/" 
credential = DefaultAzureCredential()
client = SecretClient(vault_url=vault_url, credential=credential)


# These environment variables must match exactly with the Key Vault secret names
os.environ["COSMOS_ENDPOINT"] = client.get_secret("COSMOS-ENDPOINT").value
os.environ["COSMOS_KEY"] = client.get_secret("COSMOS-KEY").value
os.environ["SENDGRID_API_KEY"] = client.get_secret("SEND-GRID-API-KEY").value

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        email = req.params.get("email")
        if not email:
            return func.HttpResponse("Missing email", status_code=400)

        endpoint = os.environ["COSMOS_ENDPOINT"]
        key = os.environ["COSMOS_KEY"]
        client = CosmosClient(endpoint, key)
        db = client.get_database_client("QuickAidDB")
        container = db.get_container_client("Tickets")

        query = "SELECT c.id, c.title, c.status FROM c WHERE c.email = @email"
        tickets = list(container.query_items(
            query=query,
            parameters=[{"name": "@email", "value": email}],
            enable_cross_partition_query=True
        ))

        return func.HttpResponse(json.dumps(tickets), status_code=200, mimetype="application/json")
    except Exception as e:
        return func.HttpResponse(str(e), status_code=500)
