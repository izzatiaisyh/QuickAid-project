import azure.functions as func
import json
import os
import uuid
from azure.cosmos import CosmosClient
from sendgrid import SendGridAPIClient
# from sendgrid.helpers.mail import Mail
from sendgrid.helpers.mail import Mail, Email, To, Content

# from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential


import logging

# func init quickaid-backend --python
# cd quickaid-backend
# func new --name submit_ticket --template "HTTP trigger" --authlevel "anonymous"

vault_url = "https://QuickAidVault.vault.azure.net/"

credential = DefaultAzureCredential()
client = SecretClient(vault_url=vault_url, credential=credential)


os.environ["COSMOS_ENDPOINT"] = client.get_secret("COSMOS-ENDPOINT").value
os.environ["COSMOS_KEY"] = client.get_secret("COSMOS-KEY").value
os.environ["SENDGRID_API_KEY"] = client.get_secret("SEND-GRID-API-KEY").value


def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        if req.method != "POST":
            return func.HttpResponse("Method not allowed", status_code=405)

        data = req.get_json()
        ticket = {
            "id": str(uuid.uuid4()),
            "title": data.get("title"),
            "email": data.get("email"),
            "category": data.get("category"),
            "description": data.get("description"),
            "status": "New"
        }

        # Cosmos DB
        endpoint = os.environ["COSMOS_ENDPOINT"]
        key = os.environ["COSMOS_KEY"]
        client = CosmosClient(endpoint, key)
        db = client.get_database_client("QuickAidDB")
        container = db.get_container_client("Tickets")
        container.create_item(body=ticket)

        # SendGrid Email
        # sg_api_key = os.environ["SENDGRID_API_KEY"]
        # sender_email = os.environ.get("FROM_EMAIL", "izzatiaisyah027@outlook.com",name="QuickAid Support")
        # message = Mail(
        #     from_email=sender_email,
        #     to_emails=ticket["email"],
        #     # subject=f"QuickAid Ticket Submitted: {ticket['title']}",
        #     subject="Your Ticket Has Been Received",
        #     html_content=f"""
        #     <p>Thank you for submitting your ticket to QuickAid.</p>
        #     <p><strong>Ticket ID:</strong> {ticket['id']}</p>
        #     <p><strong>Status:</strong> {ticket['status']}</p>
        #     <p>We'll get back to you shortly.</p>
        #     """
        # )

        sg_api_key = os.environ["SENDGRID_API_KEY"]
        # from_email_address = os.environ.get("FROM_EMAIL", "izzatiaisyah027@outlook.com")
        # sender_email = Email(from_email_address, name="QuickAid Support")
        from_email_address = os.environ.get("FROM_EMAIL", "izzatiaisyah027@outlook.com")
        sender_email = Email(from_email_address, name="QuickAid Support")

        message = Mail(
            from_email=sender_email,
            to_emails=ticket["email"],
            subject="Your Ticket Has Been Received",
            html_content=f"""
                <p>Thank you for submitting your ticket to <strong>QuickAid</strong>.</p>
                <p><strong>Ticket ID:</strong> {ticket['id']}</p>
                <p><strong>Title:</strong> {ticket['title']}</p>
                <p><strong>Category:</strong> {ticket['category']}</p>
                <p><strong>Status:</strong> {ticket['status']}</p>
                <p>We’ll get back to you shortly.</p>
            """
)
        try:
            sg = SendGridAPIClient(sg_api_key)
            sg.send(message)
        except Exception as e:
            return func.HttpResponse(f"Ticket saved, but failed to send email: {e}", status_code=500)

        return func.HttpResponse(json.dumps({
            "message": "Ticket submitted successfully",
            "id": ticket["id"]
        }), status_code=200, mimetype="application/json")

    except Exception as e:
        return func.HttpResponse(str(e), status_code=500)
